export const environment = {
  production: true,

  BASE_API_PATH: "http://sahosoftweb.com/api/",
  BASE_IMAGES_PATH: "http://sahosoftweb.com/images/",
  BASE_USERS_IMAGES_PATH: "http://sahosoftweb.com/users/"
};
